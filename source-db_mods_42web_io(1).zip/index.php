<html lang="en"><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FREE WEB HOSTING</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 15px;
        }
        
        .container {
            max-width: 1100px;
            margin: 0 auto;
        }
        
        .header {
            background: white;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .header h1 {
            color: #4361ee;
            font-size: 2rem;
            margin-bottom: 8px;
        }
        
        .header p {
            color: #666;
            font-size: 1rem;
        }
        
        .domain-example {
            background: #f8f9fa;
            padding: 10px;
            border-radius: 6px;
            margin: 10px 0;
            font-family: monospace;
            color: #4361ee;
            font-weight: bold;
            font-size: 0.9rem;
        }
        
        .main-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        @media (max-width: 768px) {
            .main-content {
                grid-template-columns: 1fr;
            }
        }
        
        .card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .card-title {
            font-size: 1.2rem;
            color: #4361ee;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
            color: #333;
            font-size: 0.9rem;
        }
        
        input, textarea, select {
            width: 100%;
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 6px;
            font-size: 0.9rem;
        }
        
        input:focus, textarea:focus {
            outline: none;
            border-color: #4361ee;
        }
        
                textarea {
            min-height: 200px;
            font-family: monospace;
            resize: vertical;
            font-size: 0.85rem;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            padding: 10px 16px;
            background: #4361ee;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 0.85rem;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.2s;
        }
        
        .btn:hover {
            background: #3a0ca3;
        }
        
        .btn-block {
            width: 100%;
            padding: 12px;
        }
        
        .btn-success {
            background: #4ade80;
        }
        
        .btn-success:hover {
            background: #22c55e;
        }
        
        .btn-warning {
            background: #f59e0b;
        }
        
        .btn-warning:hover {
            background: #d97706;
        }
        
        .url-preview {
            background: #f8f9fa;
            border: 2px dashed #4361ee;
            border-radius: 6px;
            padding: 8px;
            margin: 8px 0;
            font-family: monospace;
            color: #4361ee;
            font-weight: bold;
            text-align: center;
            font-size: 0.8rem;
        }
        
        .site-list {
            max-height: 400px;
            overflow-y: auto;
        }
        
        .site-item {
            display: flex;
            align-items: center;
            padding: 12px;
            border-bottom: 1px solid #eee;
        }
        
        .site-item:hover {
            background: #f8f9ff;
        }
        
        .site-icon {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1rem;
            margin-right: 12px;
        }
        
        .html-file { background: #e34c26; }
        .css-file { background: #264de4; }
        .js-file { background: #f7df1e; color: #000; }
        .zip-file { background: #6c757d; }
        
        .site-details {
            flex: 1;
            min-width: 0;
        }
        
        .site-name {
            font-weight: bold;
            color: #333;
            margin-bottom: 4px;
            word-break: break-all;
            font-size: 0.9rem;
        }
        
        .site-url {
            color: #666;
            font-size: 0.75rem;
            word-break: break-all;
            margin-bottom: 4px;
        }
        
        .site-meta {
            color: #888;
            font-size: 0.75rem;
            display: flex;
            gap: 12px;
        }
        
        .site-actions {
            display: flex;
            gap: 6px;
        }
        
        .message {
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 15px;
            text-align: center;
        }
        
        .success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        footer {
            text-align: center;
            color: white;
            margin-top: 30px;
            padding: 15px;
        }
        
        .tabs {
            display: flex;
            margin-bottom: 15px;
            border-bottom: 2px solid #eee;
        }
        
        .tab {
            padding: 10px 20px;
            cursor: pointer;
            border-bottom: 3px solid transparent;
            transition: all 0.2s;
            color: #666;
            font-size: 0.9rem;
        }
        
        .tab.active {
            border-bottom: 3px solid #4361ee;
            color: #4361ee;
            font-weight: bold;
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
        
        .file-input {
            padding: 20px;
            border: 2px dashed #ddd;
            border-radius: 6px;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s;
            margin-bottom: 12px;
        }
        
        .file-input:hover {
            border-color: #4361ee;
            background: #f8f9ff;
        }
        
        .file-input i {
            font-size: 2.5rem;
            color: #666;
            margin-bottom: 8px;
        }
        
        .url-box {
            background: #f8f9fa;
            border: 2px solid #e9ecef;
            border-radius: 6px;
            padding: 12px;
            margin: 12px 0;
            word-break: break-all;
        }
        
        .url-box a {
            color: #4361ee;
            text-decoration: none;
            font-weight: bold;
        }
        
        .url-box a:hover {
            text-decoration: underline;
        }
        
        .copy-btn {
            background: #6c757d;
        }
        
        .copy-btn:hover {
            background: #5a6268;
        }
        
        .stats {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-top: 15px;
        }
        
        .stat-card {
            background: linear-gradient(135deg, #4361ee, #3a0ca3);
            color: white;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }
        
        .stat-number {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 4px;
        }
        
        .stat-label {
            font-size: 0.8rem;
            opacity: 0.9;
        }
        
        .notification {
            position: fixed;
            top: 15px;
            right: 15px;
            background: #4ade80;
            color: white;
            padding: 12px 16px;
            border-radius: 6px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.2);
            transform: translateX(150%);
            transition: transform 0.3s ease;
            z-index: 1000;
        }
        
        .notification.show {
            transform: translateX(0);
        }
        
        .file-type-badge {
            display: inline-block;
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 0.65rem;
            font-weight: bold;
            color: white;
            margin-right: 6px;
        }
        
        .supported-files {
            display: flex;
            justify-content: center;
            gap: 12px;
            margin: 8px 0;
            flex-wrap: wrap;
        }
        
        .file-type {
            display: flex;
            align-items: center;
            gap: 4px;
            padding: 4px 8px;
            background: #f8f9fa;
            border-radius: 15px;
            font-size: 0.75rem;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="notification" id="notification">✅ URL COPIED TO CLIPBOARD!</div>

    <div class="container">
        <div class="header">
            <h1>🌐 FREE WEB HOSTING</h1>
            <p>HOST YOUR HTML, CSS, and JAVASCRIPT FILES WITH CUSTOM URLS!</p>
            
            <div class="supported-files">
                <div class="file-type">
                    <i class="fas fa-file-code" style="color: #e34c26;"></i>
                    HTML
                </div>
                <div class="file-type">
                    <i class="fab fa-css3-alt" style="color: #264de4;"></i>
                    CSS
                </div>
                <div class="file-type">
                    <i class="fab fa-js-square" style="color: #f7df1e;"></i>
                    JAVASCRIPT 
                </div>
                <div class="file-type">
                    <i class="fas fa-file-archive" style="color: #6c757d;"></i>
                    ZIP
                </div>
            </div>
            
            <div class="domain-example" id="domain-example">
                https://db-mods.42web.io/view.php?site=your-site-name
            </div>
        </div>

        
        
        <div class="main-content">
            <!-- Left Column - Upload -->
            <div>
                <div class="card">
                    <h2 class="card-title"><i class="fas fa-upload"></i> Upload Files</h2>
                    
                    <div class="tabs">
                        <div class="tab" onclick="switchTab('single-tab')">📄 UPLOAD FILE</div>
                        <div class="tab active" onclick="switchTab('code-tab')">📝 CODE EDITOR</div>
                    </div>
                    
                    <!-- Single File Upload Tab -->
                    <div class="tab-content" id="single-tab">
                        <form method="POST" enctype="multipart/form-data" id="upload-form">
                            <div class="form-group">
                                <label>WEBSITE NAME</label>
                                <input type="text" name="custom_url" placeholder="my-awesome-site" id="single-url" required="">
                                <div class="url-preview" id="single-preview">
                                    https://db-mods.42web.io/view.php?site=<span id="single-preview-url">my-awesome-site</span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>UPLOAD FILE</label>
                                <div class="file-input" onclick="document.getElementById('html_file').click()">
                                    <i class="fas fa-file-upload"></i>
                                    <p>CLICK TO UPLOAD FILE</p>
                                    <small>. HTML, . CSS, .JS, . ZIP FILES ALLOWED</small>
                                </div>
                                <input type="file" id="html_file" name="html_file" accept=".html,.htm,.css,.js,.zip" style="display: none;" required="">
                                <div id="file-name" style="margin-top: 8px; color: #666; font-size: 0.8rem;"></div>
                            </div>
                            <button type="submit" class="btn btn-block">
                                <i class="fas fa-cloud-upload-alt"></i> Upload &amp; Host
                            </button>
                        </form>
                    </div>
                    
                    <!-- Code Editor Tab -->
                    <div class="tab-content active" id="code-tab">
                        <form method="POST">
                            <div class="form-group">
                                <label>WEBSITE NAME</label>
                                <input type="text" name="code_custom_url" placeholder="my-website" id="code-url" required="">
                                <div class="url-preview" id="code-preview">
                                    https://db-mods.42web.io/view.php?site=<span id="code-preview-url">my-website</span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>HTML CODE</label>
                                <textarea name="html_code" placeholder="Paste your HTML code here..." required="">&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;meta name="viewport" content="width=device-width, initial-scale=1.0"&gt;
    &lt;title&gt;My Website&lt;/title&gt;
    &lt;style&gt;
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            text-align: center;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            background: rgba(255,255,255,0.1);
            padding: 40px;
            border-radius: 15px;
        }
        h1 {
            margin-bottom: 20px;
        }
    &lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;div class="container"&gt;
        &lt;h1&gt;🚀 Welcome to My Website!&lt;/h1&gt;
        &lt;p&gt;This website is hosted for free!&lt;/p&gt;
    &lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;</textarea>
                            </div>
                            <button type="submit" class="btn btn-block">
                                <i class="fas fa-code"></i> CREATE WEBSITE 
                            </button>
                        </form>
                    </div>
                </div>

                <div class="stats">
                    <div class="stat-card">
                        <div class="stat-number">10</div>
                        <div class="stat-label">SITES HOSTED</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number">15.84 KB</div>
                        <div class="stat-label">TOTAL SIZE</div>
                    </div>
                </div>
            </div>

            <!-- Right Column - Sites List -->
            <div>
                <div class="card">
                    <h2 class="card-title"><i class="fas fa-globe"></i> YOUR SITES</h2>
                    
                    <div class="site-list">
                                                                                                                    <div class="site-item">
                                    <div class="site-icon html-file">
                                        <i class="fas fa-file-code">
                                        </i>
                                    </div>
                                    <div class="site-details">
                                        <div class="site-name">
                                            <span class="file-type-badge html-file">
                                                HTML                                            </span>
                                            rayees-image-editer                                                                                    </div>
                                        <div class="site-url">https://db-mods.42web.io/view.php?site=rayees-image-editer</div>
                                        <div class="site-meta">
                                            <span>1.66 KB</span>
                                            <span>Feb 8, 2026</span>
                                        </div>
                                    </div>
                                    <div class="site-actions">
                                        <a href="https://db-mods.42web.io/view.php?site=rayees-image-editer" target="_blank" class="btn btn-success">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <button onclick="copyToClipboard('https://db-mods.42web.io/view.php?site=rayees-image-editer')" class="btn copy-btn">
                                            <i class="fas fa-copy"></i> Copy
                                        </button>
                                    </div>
                                </div>
                                                                                            <div class="site-item">
                                    <div class="site-icon html-file">
                                        <i class="fas fa-file-code">
                                        </i>
                                    </div>
                                    <div class="site-details">
                                        <div class="site-name">
                                            <span class="file-type-badge html-file">
                                                HTML                                            </span>
                                            bx-1-gaming                                                                                    </div>
                                        <div class="site-url">https://db-mods.42web.io/view.php?site=bx-1-gaming</div>
                                        <div class="site-meta">
                                            <span>891 B</span>
                                            <span>Jan 29, 2026</span>
                                        </div>
                                    </div>
                                    <div class="site-actions">
                                        <a href="https://db-mods.42web.io/view.php?site=bx-1-gaming" target="_blank" class="btn btn-success">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <button onclick="copyToClipboard('https://db-mods.42web.io/view.php?site=bx-1-gaming')" class="btn copy-btn">
                                            <i class="fas fa-copy"></i> Copy
                                        </button>
                                    </div>
                                </div>
                                                                                            <div class="site-item">
                                    <div class="site-icon html-file">
                                        <i class="fas fa-file-code">
                                        </i>
                                    </div>
                                    <div class="site-details">
                                        <div class="site-name">
                                            <span class="file-type-badge html-file">
                                                HTML                                            </span>
                                            system-h-ptar                                                                                    </div>
                                        <div class="site-url">https://db-mods.42web.io/view.php?site=system-h-ptar</div>
                                        <div class="site-meta">
                                            <span>903 B</span>
                                            <span>Jan 28, 2026</span>
                                        </div>
                                    </div>
                                    <div class="site-actions">
                                        <a href="https://db-mods.42web.io/view.php?site=system-h-ptar" target="_blank" class="btn btn-success">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <button onclick="copyToClipboard('https://db-mods.42web.io/view.php?site=system-h-ptar')" class="btn copy-btn">
                                            <i class="fas fa-copy"></i> Copy
                                        </button>
                                    </div>
                                </div>
                                                                                            <div class="site-item">
                                    <div class="site-icon html-file">
                                        <i class="fas fa-file-code">
                                        </i>
                                    </div>
                                    <div class="site-details">
                                        <div class="site-name">
                                            <span class="file-type-badge html-file">
                                                HTML                                            </span>
                                            the-ducts                                                                                    </div>
                                        <div class="site-url">https://db-mods.42web.io/view.php?site=the-ducts</div>
                                        <div class="site-meta">
                                            <span>891 B</span>
                                            <span>Jan 28, 2026</span>
                                        </div>
                                    </div>
                                    <div class="site-actions">
                                        <a href="https://db-mods.42web.io/view.php?site=the-ducts" target="_blank" class="btn btn-success">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <button onclick="copyToClipboard('https://db-mods.42web.io/view.php?site=the-ducts')" class="btn copy-btn">
                                            <i class="fas fa-copy"></i> Copy
                                        </button>
                                    </div>
                                </div>
                                                                                            <div class="site-item">
                                    <div class="site-icon html-file">
                                        <i class="fas fa-file-code">
                                        </i>
                                    </div>
                                    <div class="site-details">
                                        <div class="site-name">
                                            <span class="file-type-badge html-file">
                                                HTML                                            </span>
                                            asimdatabase                                                                                    </div>
                                        <div class="site-url">https://db-mods.42web.io/view.php?site=asimdatabase</div>
                                        <div class="site-meta">
                                            <span>3.08 KB</span>
                                            <span>Jan 27, 2026</span>
                                        </div>
                                    </div>
                                    <div class="site-actions">
                                        <a href="https://db-mods.42web.io/view.php?site=asimdatabase" target="_blank" class="btn btn-success">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <button onclick="copyToClipboard('https://db-mods.42web.io/view.php?site=asimdatabase')" class="btn copy-btn">
                                            <i class="fas fa-copy"></i> Copy
                                        </button>
                                    </div>
                                </div>
                                                                                            <div class="site-item">
                                    <div class="site-icon html-file">
                                        <i class="fas fa-file-code">
                                        </i>
                                    </div>
                                    <div class="site-details">
                                        <div class="site-name">
                                            <span class="file-type-badge html-file">
                                                HTML                                            </span>
                                            asimkhandatabase                                                                                    </div>
                                        <div class="site-url">https://db-mods.42web.io/view.php?site=asimkhandatabase</div>
                                        <div class="site-meta">
                                            <span>1.77 KB</span>
                                            <span>Jan 27, 2026</span>
                                        </div>
                                    </div>
                                    <div class="site-actions">
                                        <a href="https://db-mods.42web.io/view.php?site=asimkhandatabase" target="_blank" class="btn btn-success">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <button onclick="copyToClipboard('https://db-mods.42web.io/view.php?site=asimkhandatabase')" class="btn copy-btn">
                                            <i class="fas fa-copy"></i> Copy
                                        </button>
                                    </div>
                                </div>
                                                                                            <div class="site-item">
                                    <div class="site-icon html-file">
                                        <i class="fas fa-file-code">
                                        </i>
                                    </div>
                                    <div class="site-details">
                                        <div class="site-name">
                                            <span class="file-type-badge html-file">
                                                HTML                                            </span>
                                            asimgamehack                                                                                    </div>
                                        <div class="site-url">https://db-mods.42web.io/view.php?site=asimgamehack</div>
                                        <div class="site-meta">
                                            <span>44 B</span>
                                            <span>Jan 27, 2026</span>
                                        </div>
                                    </div>
                                    <div class="site-actions">
                                        <a href="https://db-mods.42web.io/view.php?site=asimgamehack" target="_blank" class="btn btn-success">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <button onclick="copyToClipboard('https://db-mods.42web.io/view.php?site=asimgamehack')" class="btn copy-btn">
                                            <i class="fas fa-copy"></i> Copy
                                        </button>
                                    </div>
                                </div>
                                                                                            <div class="site-item">
                                    <div class="site-icon html-file">
                                        <i class="fas fa-file-code">
                                        </i>
                                    </div>
                                    <div class="site-details">
                                        <div class="site-name">
                                            <span class="file-type-badge html-file">
                                                HTML                                            </span>
                                            gotam-x                                                                                    </div>
                                        <div class="site-url">https://db-mods.42web.io/view.php?site=gotam-x</div>
                                        <div class="site-meta">
                                            <span>891 B</span>
                                            <span>Jan 27, 2026</span>
                                        </div>
                                    </div>
                                    <div class="site-actions">
                                        <a href="https://db-mods.42web.io/view.php?site=gotam-x" target="_blank" class="btn btn-success">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <button onclick="copyToClipboard('https://db-mods.42web.io/view.php?site=gotam-x')" class="btn copy-btn">
                                            <i class="fas fa-copy"></i> Copy
                                        </button>
                                    </div>
                                </div>
                                                                                            <div class="site-item">
                                    <div class="site-icon html-file">
                                        <i class="fas fa-file-code">
                                        </i>
                                    </div>
                                    <div class="site-details">
                                        <div class="site-name">
                                            <span class="file-type-badge html-file">
                                                HTML                                            </span>
                                            zeeshan-com                                                                                    </div>
                                        <div class="site-url">https://db-mods.42web.io/view.php?site=zeeshan-com</div>
                                        <div class="site-meta">
                                            <span>891 B</span>
                                            <span>Jan 27, 2026</span>
                                        </div>
                                    </div>
                                    <div class="site-actions">
                                        <a href="https://db-mods.42web.io/view.php?site=zeeshan-com" target="_blank" class="btn btn-success">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <button onclick="copyToClipboard('https://db-mods.42web.io/view.php?site=zeeshan-com')" class="btn copy-btn">
                                            <i class="fas fa-copy"></i> Copy
                                        </button>
                                    </div>
                                </div>
                                                                                            <div class="site-item">
                                    <div class="site-icon html-file">
                                        <i class="fas fa-file-code">
                                        </i>
                                    </div>
                                    <div class="site-details">
                                        <div class="site-name">
                                            <span class="file-type-badge html-file">
                                                HTML                                            </span>
                                            index                                                                                    </div>
                                        <div class="site-url">https://db-mods.42web.io/view.php?site=index</div>
                                        <div class="site-meta">
                                            <span>4.93 KB</span>
                                            <span>Jan 27, 2026</span>
                                        </div>
                                    </div>
                                    <div class="site-actions">
                                        <a href="https://db-mods.42web.io/view.php?site=index" target="_blank" class="btn btn-success">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <button onclick="copyToClipboard('https://db-mods.42web.io/view.php?site=index')" class="btn copy-btn">
                                            <i class="fas fa-copy"></i> Copy
                                        </button>
                                    </div>
                                </div>
                                                                        </div>
                </div>
            </div>
        </div>

        <footer>
            <p style="font-size: 0.9rem;">DEVELOPED BY <strong style="color: #4cc9f0;">DB-MODS</strong></p>
        </footer>
    </div>

    <script>
        // Tab switching
        function switchTab(tabId) {
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.remove('active');
            });
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            document.getElementById(tabId).classList.add('active');
            event.target.classList.add('active');
        }

        // URL preview update
        function updateUrlPreview(inputId, previewId) {
            const input = document.getElementById(inputId);
            const preview = document.getElementById(previewId);
            
            input.addEventListener('input', function() {
                let url = this.value.trim().toLowerCase();
                url = url.replace(/[^a-z0-9-]/g, '-');
                url = url.replace(/-+/g, '-');
                url = url.replace(/^-|-$/g, '');
                
                if (url === '') {
                    url = 'my-site';
                }
                
                preview.textContent = url;
            });
        }

        // Initialize URL previews
        updateUrlPreview('single-url', 'single-preview-url');
        updateUrlPreview('code-url', 'code-preview-url');

        // File input display
        document.getElementById('html_file').addEventListener('change', function(e) {
            const fileName = document.getElementById('file-name');
            if (this.files.length > 0) {
                const file = this.files[0];
                const fileExt = file.name.split('.').pop().toLowerCase();
                const allowedExt = ['html', 'htm', 'css', 'js', 'zip'];
                
                if (!allowedExt.includes(fileExt)) {
                    fileName.innerHTML = '<span style="color: #dc2626;">❌ ONLY HTML, CSS, JS, ZIP FILES ALLOWED</span>';
                    this.value = '';
                    return;
                }
                
                fileName.innerHTML = '<i class="fas fa-file"></i> Selected: ' + file.name;
                fileName.style.color = '#4361ee';
                
                // Auto-fill URL from filename
                const filename = file.name.replace(/\.[^/.]+$/, "");
                document.getElementById('single-url').value = filename.toLowerCase().replace(/[^a-z0-9]/g, '-');
                document.getElementById('single-preview-url').textContent = filename.toLowerCase().replace(/[^a-z0-9]/g, '-');
            } else {
                fileName.innerHTML = '';
            }
        });

        // Copy to clipboard function
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(() => {
                showNotification('✅ URL COPIED TO CLIPBOARD!');
            }).catch(err => {
                showNotification('❌ FAILED TO COPY URL');
            });
        }

        // Show notification
        function showNotification(message) {
            const notification = document.getElementById('notification');
            notification.textContent = message;
            notification.classList.add('show');
            
            setTimeout(() => {
                notification.classList.remove('show');
            }, 2000);
        }

        // Form validation
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function(e) {
                const urlInput = this.querySelector('input[type="text"]');
                if (urlInput) {
                    let url = urlInput.value.trim().toLowerCase();
                    url = url.replace(/[^a-z0-9-]/g, '-');
                    url = url.replace(/-+/g, '-');
                    url = url.replace(/^-|-$/g, '');
                    urlInput.value = url || 'my-site';
                }
            });
        });
    </script>


</body></html>