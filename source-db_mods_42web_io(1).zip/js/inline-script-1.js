
        // Tab switching
        function switchTab(tabId) {
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.remove('active');
            });
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            document.getElementById(tabId).classList.add('active');
            event.target.classList.add('active');
        }

        // URL preview update
        function updateUrlPreview(inputId, previewId) {
            const input = document.getElementById(inputId);
            const preview = document.getElementById(previewId);
            
            input.addEventListener('input', function() {
                let url = this.value.trim().toLowerCase();
                url = url.replace(/[^a-z0-9-]/g, '-');
                url = url.replace(/-+/g, '-');
                url = url.replace(/^-|-$/g, '');
                
                if (url === '') {
                    url = 'my-site';
                }
                
                preview.textContent = url;
            });
        }

        // Initialize URL previews
        updateUrlPreview('single-url', 'single-preview-url');
        updateUrlPreview('code-url', 'code-preview-url');

        // File input display
        document.getElementById('html_file').addEventListener('change', function(e) {
            const fileName = document.getElementById('file-name');
            if (this.files.length > 0) {
                const file = this.files[0];
                const fileExt = file.name.split('.').pop().toLowerCase();
                const allowedExt = ['html', 'htm', 'css', 'js', 'zip'];
                
                if (!allowedExt.includes(fileExt)) {
                    fileName.innerHTML = '<span style="color: #dc2626;">❌ ONLY HTML, CSS, JS, ZIP FILES ALLOWED</span>';
                    this.value = '';
                    return;
                }
                
                fileName.innerHTML = '<i class="fas fa-file"></i> Selected: ' + file.name;
                fileName.style.color = '#4361ee';
                
                // Auto-fill URL from filename
                const filename = file.name.replace(/\.[^/.]+$/, "");
                document.getElementById('single-url').value = filename.toLowerCase().replace(/[^a-z0-9]/g, '-');
                document.getElementById('single-preview-url').textContent = filename.toLowerCase().replace(/[^a-z0-9]/g, '-');
            } else {
                fileName.innerHTML = '';
            }
        });

        // Copy to clipboard function
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(() => {
                showNotification('✅ URL COPIED TO CLIPBOARD!');
            }).catch(err => {
                showNotification('❌ FAILED TO COPY URL');
            });
        }

        // Show notification
        function showNotification(message) {
            const notification = document.getElementById('notification');
            notification.textContent = message;
            notification.classList.add('show');
            
            setTimeout(() => {
                notification.classList.remove('show');
            }, 2000);
        }

        // Form validation
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function(e) {
                const urlInput = this.querySelector('input[type="text"]');
                if (urlInput) {
                    let url = urlInput.value.trim().toLowerCase();
                    url = url.replace(/[^a-z0-9-]/g, '-');
                    url = url.replace(/-+/g, '-');
                    url = url.replace(/^-|-$/g, '');
                    urlInput.value = url || 'my-site';
                }
            });
        });
    